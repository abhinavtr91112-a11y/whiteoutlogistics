import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Services from './components/Services';
import Tracking from './components/Tracking';
import Contact from './components/Contact';
import Login from './components/Login';
import WhyChooseUs from './components/WhyChooseUs';
import Footer from './components/Footer';
import Chatbot from './components/Chatbot';
import { Building2, Calendar, Users, FileText, BarChart3, CheckCircle2, ArrowRight } from 'lucide-react';

export default function App() {
  const [page, setPage] = useState('home');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 1800);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [page]);

  // Preloader
  if (loading) {
    return (
      <div className="fixed inset-0 bg-navy flex flex-col items-center justify-center z-[100]">
        <img src="/images/logo.png" alt="Loading" className="h-14 rounded-xl mb-6 opacity-80" />
        <div className="text-white text-[15px] font-bold tracking-[0.15em] mb-1">WHITEOUT LOGISTICS</div>
        <div className="text-blue-light text-[11px] tracking-[0.35em] font-medium mb-10">PRIVATE LIMITED</div>
        <div className="w-40 h-[2px] bg-white/[0.06] rounded-full overflow-hidden">
          <div className="h-full bg-blue rounded-full" style={{ animation: 'shimmer 1.5s ease-in-out infinite', width: '40%' }} />
        </div>
      </div>
    );
  }

  // Login — standalone page
  if (page === 'login') {
    return (
      <>
        <Login navigate={setPage} />
        <Chatbot />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Navbar current={page} navigate={setPage} />

      <main>
        {page === 'home' && (
          <>
            <Hero navigate={setPage} />

            {/* Company snapshot */}
            <section className="py-20 bg-white">
              <div className="max-w-7xl mx-auto px-5 lg:px-8">
                <div className="grid lg:grid-cols-2 gap-16 items-center">
                  <div>
                    <div className="flex items-center gap-3 mb-4">
                      <span className="w-10 h-[1px] bg-blue" />
                      <span className="text-blue text-[13px] font-semibold tracking-widest uppercase">Company Overview</span>
                    </div>
                    <h2 className="text-3xl lg:text-4xl font-extrabold text-navy leading-tight mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
                      Whiteout Logistics Private Limited
                    </h2>
                    <p className="text-text-light text-[15px] leading-relaxed mb-8">
                      An India-based domestic logistics company incorporated with the Ministry of Corporate 
                      Affairs, specializing in truck transport and road freight services. Registered under 
                      RoC-Mumbai II and actively serving clients across all Indian states.
                    </p>

                    <div className="grid grid-cols-2 gap-4 mb-8">
                      {[
                        { icon: <FileText size={18} />, label: 'CIN', value: 'U52290MH2024PTC423370' },
                        { icon: <Calendar size={18} />, label: 'Incorporated', value: '11 April 2024' },
                        { icon: <Building2 size={18} />, label: 'ROC', value: 'RoC-Mumbai II' },
                        { icon: <Users size={18} />, label: 'Directors', value: '2 Key Personnel' },
                        { icon: <BarChart3 size={18} />, label: 'Last AGM', value: '30 Sept 2025' },
                        { icon: <CheckCircle2 size={18} />, label: 'Status', value: 'Active' },
                      ].map((item, i) => (
                        <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-off-white">
                          <div className="text-blue mt-0.5">{item.icon}</div>
                          <div>
                            <div className="text-[11px] text-text-light font-medium tracking-wider uppercase">{item.label}</div>
                            <div className="text-[13px] font-semibold text-navy mt-0.5">{item.value}</div>
                          </div>
                        </div>
                      ))}
                    </div>

                    <button
                      onClick={() => setPage('about')}
                      className="group flex items-center gap-2 text-blue text-[14px] font-semibold hover:gap-3 transition-all"
                    >
                      Full Company Details <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                    </button>
                  </div>

                  <div className="relative">
                    <img
                      src="/images/shipping.jpg"
                      alt="Domestic Transport"
                      className="w-full h-[440px] object-cover rounded-2xl"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-navy/40 to-transparent rounded-2xl" />
                    <div className="absolute bottom-6 left-6 right-6 bg-white/95 backdrop-blur-sm rounded-xl p-5 shadow-lg border border-border">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-[12px] text-text-light font-medium">Led by</div>
                          <div className="text-navy font-bold text-[15px]">Anupam Tripathi & Nitu Anupam Tripathi</div>
                          <div className="text-blue text-[12px] font-medium">Directors</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <WhyChooseUs />
            <Services navigate={setPage} />
          </>
        )}

        {page === 'about' && <About />}
        {page === 'services' && <Services navigate={setPage} />}
        {page === 'tracking' && <Tracking />}
        {page === 'contact' && <Contact />}
      </main>

      <Footer navigate={setPage} />
      <Chatbot />
    </div>
  );
}
