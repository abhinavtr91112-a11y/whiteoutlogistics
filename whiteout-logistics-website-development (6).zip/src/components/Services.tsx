import { Truck, Package, MapPinCheck, FileCheck, Warehouse, BarChart3, ArrowRight } from 'lucide-react';

interface Props {
  navigate: (p: string) => void;
}

const services = [
  {
    icon: <Truck size={24} />,
    title: 'Full Truckload (FTL)',
    desc: 'Dedicated truck services for large volume shipments across India. Direct routes with no transit stops for faster delivery.',
    points: ['Dedicated vehicles', 'Pan-India routes', 'Express & standard options'],
  },
  {
    icon: <Package size={24} />,
    title: 'Part Truckload (PTL)',
    desc: 'Cost-effective shared truck solutions for smaller shipments. Consolidated freight across all major Indian cities.',
    points: ['Shared capacity', 'Hub-to-hub network', 'Economy pricing'],
  },
  {
    icon: <MapPinCheck size={24} />,
    title: 'Last-Mile Delivery',
    desc: 'Reliable doorstep delivery services covering urban and rural areas across every state in India.',
    points: ['Urban & rural coverage', 'Proof of delivery', 'Real-time updates'],
  },
  {
    icon: <FileCheck size={24} />,
    title: 'Documentation & Compliance',
    desc: 'Complete handling of e-way bills, GST documentation, transit permits, and all regulatory paperwork.',
    points: ['E-way bill generation', 'GST compliance', 'Transit insurance'],
  },
  {
    icon: <Warehouse size={24} />,
    title: 'Warehousing & Storage',
    desc: 'Secure warehousing facilities with modern inventory management systems at strategic locations across India.',
    points: ['Inventory management', 'Pick, pack & dispatch', '24/7 security'],
  },
  {
    icon: <BarChart3 size={24} />,
    title: 'Supply Chain Solutions',
    desc: 'End-to-end supply chain design and management to optimize your domestic distribution network.',
    points: ['Route optimization', 'Vendor management', 'Cost analytics'],
  },
];

export default function Services({ navigate }: Props) {
  return (
    <section className="pt-28 pb-20 bg-off-white">
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        {/* Header */}
        <div className="max-w-2xl mb-16">
          <div className="flex items-center gap-3 mb-4">
            <span className="w-10 h-[1px] bg-blue" />
            <span className="text-blue text-[13px] font-semibold tracking-widest uppercase">What We Do</span>
          </div>
          <h2 className="text-3xl lg:text-[2.8rem] font-extrabold text-navy leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
            Domestic Transport & Logistics
          </h2>
          <p className="text-text-light text-base mt-4 leading-relaxed">
            From pickup to doorstep — we manage your goods across every highway and city in India with full truckload and part load solutions.
          </p>
        </div>

        {/* Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s, i) => (
            <div
              key={i}
              className="group bg-white border border-border rounded-2xl p-7 hover:shadow-xl hover:shadow-navy/[0.05] hover:border-blue/20 transition-all duration-400 relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-[2px] bg-blue scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left" />
              
              <div className="w-12 h-12 rounded-xl bg-blue/[0.07] text-blue flex items-center justify-center mb-5 group-hover:bg-blue group-hover:text-white transition-all duration-300">
                {s.icon}
              </div>
              
              <h3 className="text-lg font-bold text-navy mb-3">{s.title}</h3>
              <p className="text-text-light text-[14px] leading-relaxed mb-5">{s.desc}</p>
              
              <ul className="space-y-2 mb-6">
                {s.points.map((p, j) => (
                  <li key={j} className="flex items-center gap-2.5 text-[13px] text-text-light">
                    <span className="w-1 h-1 rounded-full bg-blue flex-shrink-0" />
                    {p}
                  </li>
                ))}
              </ul>

              <button
                onClick={() => navigate('contact')}
                className="flex items-center gap-2 text-blue text-[13px] font-semibold hover:gap-3 transition-all"
              >
                Request Quote <ArrowRight size={14} />
              </button>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-16 bg-navy rounded-2xl p-8 lg:p-12 flex flex-col lg:flex-row items-center justify-between gap-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-80 h-80 bg-blue/[0.06] rounded-full -translate-y-1/2 translate-x-1/3" />
          <div className="relative z-10">
            <h3 className="text-white text-xl lg:text-2xl font-bold mb-2">Need a custom transport solution?</h3>
            <p className="text-white/40 text-[15px]">Our team will plan the best routes and pricing for your domestic shipments.</p>
          </div>
          <button
            onClick={() => navigate('contact')}
            className="relative z-10 bg-blue hover:bg-blue-dark text-white px-8 py-3.5 rounded-lg text-sm font-semibold tracking-wide transition-all flex items-center gap-2 whitespace-nowrap"
          >
            Get a Quote <ArrowRight size={16} />
          </button>
        </div>
      </div>
    </section>
  );
}
