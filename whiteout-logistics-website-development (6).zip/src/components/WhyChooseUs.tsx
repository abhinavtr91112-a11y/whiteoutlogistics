import { Shield, MapPinned, BarChart3, Users, Zap, Award } from 'lucide-react';

export default function WhyChooseUs() {
  const reasons = [
    {
      icon: <Shield size={22} />,
      title: 'MCA Registered & Compliant',
      desc: 'Officially registered under ROC Mumbai II with CIN U52290MH2024PTC423370. Fully compliant with GST, e-way bill, and all transport regulations.',
    },
    {
      icon: <MapPinned size={22} />,
      title: 'Pan-India Coverage',
      desc: 'Truck transport operations covering all 28 states and 8 union territories of India through our extensive highway network.',
    },
    {
      icon: <BarChart3 size={22} />,
      title: 'Real-Time GPS Tracking',
      desc: 'Live tracking with integrated Google Maps so you know the exact location of your goods on Indian roads at every moment.',
    },
    {
      icon: <Users size={22} />,
      title: 'Experienced Leadership',
      desc: 'Led by directors Anupam Tripathi and Nitu Anupam Tripathi with hands-on expertise in domestic freight and logistics.',
    },
    {
      icon: <Zap size={22} />,
      title: 'Reliable & On Time',
      desc: '99.2% on-time delivery rate across India. We understand that timely delivery is the backbone of your business operations.',
    },
    {
      icon: <Award size={22} />,
      title: 'Competitive Rates',
      desc: 'Optimized route planning and consolidated freight ensure the most competitive rates for FTL and PTL shipments.',
    },
  ];

  return (
    <>
      {/* Why Choose Us */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <span className="w-10 h-[1px] bg-blue" />
                <span className="text-blue text-[13px] font-semibold tracking-widest uppercase">Why Us</span>
              </div>
              <h2 className="text-3xl lg:text-[2.8rem] font-extrabold text-navy leading-tight mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
                Why Choose Whiteout Logistics
              </h2>
              <p className="text-text-light text-[15px] leading-relaxed mb-8">
                We don't just move goods — we build trust through transparency, reliability, and an 
                unwavering commitment to safe, on-time delivery across every corner of India.
              </p>
              <div className="relative rounded-2xl overflow-hidden">
                <img src="/images/shipping.jpg" alt="Truck Transport" className="w-full h-64 object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-navy/50 to-transparent" />
              </div>
            </div>

            <div className="grid gap-4">
              {reasons.map((r, i) => (
                <div
                  key={i}
                  className="group flex items-start gap-4 p-5 rounded-xl border border-transparent hover:border-border hover:bg-off-white/60 transition-all duration-300"
                >
                  <div className="w-11 h-11 rounded-xl bg-blue/[0.07] text-blue flex items-center justify-center flex-shrink-0 group-hover:bg-blue group-hover:text-white transition-all duration-300">
                    {r.icon}
                  </div>
                  <div>
                    <h3 className="text-[15px] font-bold text-navy mb-1">{r.title}</h3>
                    <p className="text-text-light text-[13px] leading-relaxed">{r.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Industries */}
      <section className="py-14 bg-off-white border-y border-border">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <p className="text-center text-text-light text-[12px] font-semibold tracking-[0.2em] uppercase mb-8">
            Trusted Across Industries
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            {['Manufacturing', 'Pharmaceuticals', 'FMCG', 'Automotive', 'Textiles', 'Electronics', 'Chemicals', 'Construction', 'Agriculture', 'E-Commerce'].map((ind, i) => (
              <span
                key={i}
                className="text-text-light text-[13px] font-medium px-5 py-2.5 bg-white rounded-lg border border-border hover:border-blue/30 hover:text-blue transition-all cursor-default"
              >
                {ind}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-navy">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="text-center mb-14">
            <div className="flex items-center justify-center gap-3 mb-4">
              <span className="w-10 h-[1px] bg-blue-light" />
              <span className="text-blue-light text-[13px] font-semibold tracking-widest uppercase">Client Feedback</span>
              <span className="w-10 h-[1px] bg-blue-light" />
            </div>
            <h2 className="text-3xl lg:text-4xl font-extrabold text-white" style={{ fontFamily: 'var(--font-heading)' }}>
              What Our Clients Say
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                name: 'Rajesh Kumar',
                company: 'Kumar Manufacturing, Pune',
                text: 'Whiteout Logistics handles our Mumbai-to-Delhi route flawlessly. Their GPS tracking gives us complete peace of mind. The goods always arrive on time and in perfect condition.',
              },
              {
                name: 'Priya Sharma',
                company: 'FreshPack Foods, Mumbai',
                text: 'We needed a reliable partner for our FMCG distribution across Maharashtra. Whiteout delivered — literally. Their documentation and e-way bill handling is seamless.',
              },
              {
                name: 'Vikram Patel',
                company: 'AutoParts India, Ahmedabad',
                text: 'Competitive pricing, on-time delivery, and real-time updates. Whiteout Logistics has been instrumental in optimizing our Gujarat-to-Karnataka supply chain.',
              },
            ].map((t, i) => (
              <div key={i} className="bg-white/[0.04] border border-white/[0.06] rounded-2xl p-7 hover:bg-white/[0.07] transition-all">
                <div className="flex gap-1 mb-4">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <svg key={s} className="w-4 h-4 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <p className="text-white/60 text-[14px] leading-relaxed mb-6 italic">"{t.text}"</p>
                <div>
                  <div className="text-white text-[14px] font-semibold">{t.name}</div>
                  <div className="text-white/30 text-[12px]">{t.company}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
