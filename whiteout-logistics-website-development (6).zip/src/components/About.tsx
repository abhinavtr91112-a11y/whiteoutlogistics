import { Building2, Calendar, MapPin, IndianRupee, FileText, Shield } from 'lucide-react';

export default function About() {
  const details = [
    { icon: <FileText size={18} />, label: 'CIN', value: 'U52290MH2024PTC423370' },
    { icon: <Calendar size={18} />, label: 'Date of Incorporation', value: '11th April, 2024' },
    { icon: <Building2 size={18} />, label: 'Company Class', value: 'Private (Non-Govt)' },
    { icon: <Shield size={18} />, label: 'Registrar', value: 'RoC-Mumbai II' },
    { icon: <IndianRupee size={18} />, label: 'Authorized Capital', value: '₹1,00,000' },
    { icon: <IndianRupee size={18} />, label: 'Paid-up Capital', value: '₹1,00,000' },
  ];

  return (
    <section className="pt-28 pb-20 bg-white">
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        {/* Header */}
        <div className="max-w-2xl mb-16">
          <div className="flex items-center gap-3 mb-4">
            <span className="w-10 h-[1px] bg-blue" />
            <span className="text-blue text-[13px] font-semibold tracking-widest uppercase">About the Company</span>
          </div>
          <h2 className="text-3xl lg:text-[2.8rem] font-extrabold text-navy leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
            Whiteout Logistics Private Limited
          </h2>
        </div>

        {/* Main content */}
        <div className="grid lg:grid-cols-2 gap-16 items-start mb-24">
          <div>
            <div className="relative rounded-2xl overflow-hidden">
              <img
                src="/images/warehouse.jpg"
                alt="Whiteout Logistics Operations"
                className="w-full h-[400px] object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-navy/60 to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between">
                <div>
                  <div className="text-white/60 text-xs font-medium tracking-wider uppercase">Established</div>
                  <div className="text-white text-2xl font-bold">2024</div>
                </div>
                <div className="bg-green-500 text-white text-xs font-bold px-3 py-1.5 rounded-md tracking-wider uppercase">
                  Active
                </div>
              </div>
            </div>
          </div>

          <div>
            <p className="text-text-light text-[15px] leading-[1.85] mb-6">
              WHITEOUT LOGISTICS PRIVATE LIMITED (CIN: U52290MH2024PTC423370) is a Private company 
              incorporated with the Ministry of Corporate Affairs on 11th April, 2024. Classified as 
              a Non-government Private company, it is registered at the Registrar of Companies (ROC), 
              RoC-Mumbai II, with an Authorized Share Capital of ₹1,00,000 and a paid-up capital of ₹1,00,000.
            </p>
            <p className="text-text-light text-[15px] leading-[1.85] mb-6">
              We are an India-based domestic logistics company specializing in road transport and truck 
              freight services. Our operations cover all 28 states and 8 union territories, ensuring 
              seamless goods movement across the country via our fleet of commercial vehicles.
            </p>
            <p className="text-text-light text-[15px] leading-[1.85] mb-8">
              The company's registration number is 423370. The last Annual General Meeting (AGM) was held on 
              30th September, 2025, and the most recent financial update was filed on 31st March, 2025. 
              The company has 2 directors — <strong className="text-navy">Anupam Tripathi</strong> and 
              <strong className="text-navy"> Nitu Anupam Tripathi</strong>.
            </p>

            {/* Details grid */}
            <div className="grid grid-cols-2 gap-3">
              {details.map((d, i) => (
                <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-off-white group hover:bg-blue/[0.04] transition-colors">
                  <div className="text-blue mt-0.5">{d.icon}</div>
                  <div>
                    <div className="text-[11px] text-text-light font-medium tracking-wider uppercase">{d.label}</div>
                    <div className="text-[13px] font-semibold text-navy mt-0.5">{d.value}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Directors */}
        <div className="mb-24">
          <div className="flex items-center gap-3 mb-10">
            <span className="w-10 h-[1px] bg-blue" />
            <span className="text-blue text-[13px] font-semibold tracking-widest uppercase">Leadership</span>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl">
            {[
              {
                name: 'Anupam Tripathi',
                role: 'Director',
                img: '/images/director1.jpg',
                bio: 'A visionary leader with deep expertise in domestic logistics and road transport, driving Whiteout Logistics towards operational excellence and pan-India expansion.',
              },
              {
                name: 'Nitu Anupam Tripathi',
                role: 'Director',
                img: '/images/director2.jpg',
                bio: 'A strategic leader ensuring the company maintains the highest standards of service delivery, compliance, and sustainable business growth across all verticals.',
              },
            ].map((d, i) => (
              <div key={i} className="group bg-white border border-border rounded-2xl overflow-hidden hover:shadow-xl hover:shadow-navy/[0.06] transition-all duration-500">
                <div className="relative h-72 overflow-hidden">
                  <img
                    src={d.img}
                    alt={d.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy/70 via-transparent to-transparent" />
                  <div className="absolute bottom-5 left-6">
                    <div className="text-white text-xl font-bold">{d.name}</div>
                    <div className="text-blue-light text-[13px] font-medium tracking-wide">{d.role}</div>
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-text-light text-[14px] leading-relaxed">{d.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Registered address */}
        <div className="bg-navy rounded-2xl p-8 lg:p-10 flex flex-col md:flex-row items-start gap-6">
          <div className="w-12 h-12 rounded-xl bg-blue/10 flex items-center justify-center flex-shrink-0">
            <MapPin size={22} className="text-blue-light" />
          </div>
          <div>
            <h3 className="text-white text-lg font-bold mb-2">Registered Office</h3>
            <p className="text-white/50 text-[15px] leading-relaxed">
              Flat No. 204/b, Sangam Ap, Barrage Road, Badlapur We, Badlapur E.d.,
              Thane, Ambarnath, Maharashtra, India — 421503
            </p>
            <div className="flex flex-wrap gap-4 mt-4 text-[13px]">
              <span className="text-white/30">Registration No: <span className="text-white/60">423370</span></span>
              <span className="text-white/30">Last AGM: <span className="text-white/60">30 Sept 2025</span></span>
              <span className="text-white/30">Financials: <span className="text-white/60">31 Mar 2025</span></span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
