import { useState, useEffect, useCallback } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';

interface Props {
  navigate: (p: string) => void;
}

const slides = [
  {
    tag: 'Domestic Logistics Solutions',
    heading: ['Reliable', 'Road Transport', 'Across India'],
    sub: 'End-to-end domestic logistics and truck transportation services. MCA-registered operations delivering goods safely across every state of India.',
  },
  {
    tag: 'Real-Time Visibility',
    heading: ['Track Every', 'Shipment,', 'Anywhere'],
    sub: 'Advanced GPS-enabled tracking with live map integration. Know the exact location and status of your cargo on Indian highways in real time.',
  },
  {
    tag: 'Since 2024 · CIN U52290MH2024PTC423370',
    heading: ['Your Trusted', 'Transport', 'Partner'],
    sub: 'A registered Private company delivering full truckload, part load, last-mile delivery, warehousing, and complete supply chain management pan-India.',
  },
];

export default function Hero({ navigate }: Props) {
  const [idx, setIdx] = useState(0);
  const [animKey, setAnimKey] = useState(0);

  const goTo = useCallback((i: number) => {
    setIdx(i);
    setAnimKey((k) => k + 1);
  }, []);

  useEffect(() => {
    const t = setInterval(() => goTo((idx + 1) % slides.length), 6000);
    return () => clearInterval(t);
  }, [idx, goTo]);

  const slide = slides[idx];

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden bg-navy">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src="/images/hero-bg.jpg"
          alt=""
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-navy via-navy/95 to-navy/60" />
        <div className="absolute inset-0 bg-gradient-to-t from-navy via-transparent to-navy/40" />
      </div>

      {/* Geometric accents */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] border border-white/[0.03] rounded-full -translate-y-1/2 translate-x-1/3" />
      <div className="absolute bottom-0 right-1/4 w-[400px] h-[400px] border border-blue/[0.06] rounded-full translate-y-1/2" />
      <div className="absolute top-1/3 right-[15%] w-1 h-32 bg-gradient-to-b from-blue/40 to-transparent" />

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-5 lg:px-8 pt-32 pb-24 w-full">
        <div className="max-w-3xl" key={animKey}>
          {/* Tag */}
          <div className="anim-fade-up flex items-center gap-3 mb-8">
            <span className="w-10 h-[1px] bg-blue" />
            <span className="text-blue text-[13px] font-semibold tracking-widest uppercase">
              {slide.tag}
            </span>
          </div>

          {/* Heading */}
          <h1 className="mb-8">
            {slide.heading.map((line, i) => (
              <span
                key={i}
                className="block anim-fade-up text-white leading-[1.08]"
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: 'clamp(2.4rem, 5.5vw, 4.5rem)',
                  fontWeight: 800,
                  animationDelay: `${i * 0.12}s`,
                }}
              >
                {i === 0 ? (
                  <span className="text-blue-light">{line}</span>
                ) : (
                  line
                )}
              </span>
            ))}
          </h1>

          {/* Sub */}
          <p
            className="anim-fade-up text-white/50 text-base lg:text-lg leading-relaxed max-w-xl mb-12"
            style={{ animationDelay: '0.35s' }}
          >
            {slide.sub}
          </p>

          {/* Actions */}
          <div className="anim-fade-up flex flex-wrap gap-4" style={{ animationDelay: '0.5s' }}>
            <button
              onClick={() => navigate('tracking')}
              className="group flex items-center gap-3 bg-blue hover:bg-blue-dark text-white px-7 py-3.5 rounded-lg text-sm font-semibold tracking-wide transition-all"
            >
              Track Shipment
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={() => navigate('services')}
              className="flex items-center gap-3 border border-white/20 hover:border-white/40 text-white/80 hover:text-white px-7 py-3.5 rounded-lg text-sm font-semibold tracking-wide transition-all"
            >
              Explore Services
            </button>
          </div>
        </div>

        {/* Stats bar */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-px bg-white/[0.06] rounded-xl overflow-hidden">
          {[
            { val: '28+', label: 'States Covered' },
            { val: '10,000+', label: 'Deliveries' },
            { val: '500+', label: 'Clients' },
            { val: '99.2%', label: 'On-Time Rate' },
          ].map((s, i) => (
            <div
              key={i}
              className="bg-navy/60 backdrop-blur-sm px-6 py-6 text-center hover:bg-white/[0.04] transition-colors"
            >
              <div className="text-2xl lg:text-3xl font-bold text-white tracking-tight">{s.val}</div>
              <div className="text-white/40 text-xs font-medium tracking-wider uppercase mt-1">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Slide controls */}
        <div className="mt-10 flex items-center gap-4">
          <button
            onClick={() => goTo((idx - 1 + slides.length) % slides.length)}
            className="w-10 h-10 rounded-full border border-white/10 hover:border-white/30 flex items-center justify-center text-white/40 hover:text-white transition-all"
          >
            <ChevronLeft size={18} />
          </button>
          <div className="flex gap-2">
            {slides.map((_, i) => (
              <button
                key={i}
                onClick={() => goTo(i)}
                className={`h-[3px] rounded-full transition-all duration-500 ${
                  i === idx ? 'w-10 bg-blue' : 'w-5 bg-white/20 hover:bg-white/30'
                }`}
              />
            ))}
          </div>
          <button
            onClick={() => goTo((idx + 1) % slides.length)}
            className="w-10 h-10 rounded-full border border-white/10 hover:border-white/30 flex items-center justify-center text-white/40 hover:text-white transition-all"
          >
            <ChevronRight size={18} />
          </button>
        </div>
      </div>
    </section>
  );
}
