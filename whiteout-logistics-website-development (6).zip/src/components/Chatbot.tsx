import { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Sparkles } from 'lucide-react';

interface Msg {
  from: 'bot' | 'user';
  text: string;
}

// Comprehensive company knowledge base
const KNOWLEDGE = {
  company: {
    name: 'WHITEOUT LOGISTICS PRIVATE LIMITED',
    cin: 'U52290MH2024PTC423370',
    registrationNumber: '423370',
    incorporationDate: '11th April, 2024',
    companyAge: '2 years, 1 month & 26 days',
    type: 'Private Company',
    category: 'Non-Government Company',
    roc: 'Registrar of Companies, RoC-Mumbai II',
    status: 'Active',
    authorizedCapital: '₹1,00,000',
    paidUpCapital: '₹1,00,000',
    lastAgm: '30th September, 2025',
    lastFinancialUpdate: '31st March, 2025',
    state: 'Maharashtra',
    country: 'India',
  },
  address: {
    full: 'Flat No. 204/b, Sangam Ap, Barrage Road, Badlapur We, Badlapur E.d., Thane, Ambarnath, Maharashtra, India - 421503',
    flatNo: '204/b',
    building: 'Sangam Ap',
    road: 'Barrage Road',
    area: 'Badlapur We, Badlapur E.d.',
    district: 'Thane',
    city: 'Ambarnath',
    state: 'Maharashtra',
    pincode: '421503',
    country: 'India',
  },
  directors: [
    {
      name: 'Anupam Tripathi',
      role: 'Director',
      description: 'Visionary leader with extensive experience in domestic logistics and road transport operations. Drives strategic business development and oversees pan-India partnerships.',
    },
    {
      name: 'Nitu Anupam Tripathi', 
      role: 'Director',
      description: 'Strategic leader responsible for operational excellence, corporate governance, and ensuring sustainable business growth across all verticals.',
    },
  ],
  contact: {
    email: 'info@whiteoutlogistics.com',
    phone: '+91 9767247858',
    businessHours: 'Monday to Saturday, 9:00 AM to 6:00 PM IST',
    website: 'whiteoutlogistics.com',
  },
  services: [
    {
      name: 'Full Truckload (FTL)',
      description: 'Dedicated truck services for large volume shipments across India. Direct point-to-point routes with no transit stops for faster delivery.',
      features: ['Dedicated vehicles', 'Pan-India routes', 'Express & standard options', 'Open & closed body trucks', 'Flatbed trailers', 'Container trucks'],
    },
    {
      name: 'Part Truckload (PTL)',
      description: 'Cost-effective shared truck solutions for smaller shipments. Consolidated freight across all major Indian cities and towns.',
      features: ['Shared capacity', 'Hub-to-hub network', 'Economy pricing', 'Scheduled departures', 'Multi-city routes', 'Small consignments'],
    },
    {
      name: 'Last-Mile Delivery',
      description: 'Reliable doorstep delivery services covering urban and rural areas across every state in India.',
      features: ['Urban & rural coverage', 'Proof of delivery', 'Real-time updates', 'Same-day options', 'COD handling', 'Return pickup'],
    },
    {
      name: 'Documentation & Compliance',
      description: 'Complete handling of e-way bills, GST documentation, transit permits, insurance, and all regulatory paperwork for domestic transport.',
      features: ['E-way bill generation', 'GST compliance', 'Transit insurance', 'Permit management', 'Goods receipt', 'Digital documentation'],
    },
    {
      name: 'Warehousing & Storage',
      description: 'Secure warehousing facilities with modern inventory management systems at strategic locations across India.',
      features: ['Inventory management', 'Pick, pack & dispatch', '24/7 security', 'CCTV surveillance', 'Cross-docking', 'Distribution hub'],
    },
    {
      name: 'Supply Chain Solutions',
      description: 'End-to-end supply chain design and management to optimize your domestic distribution network and reduce costs.',
      features: ['Route optimization', 'Vendor management', 'Cost analytics', 'Demand planning', 'Fleet management', 'Technology integration'],
    },
  ],
  tracking: {
    format: 'WL-YYYY-XXXXXX (e.g., WL-2025-001234)',
    features: ['Real-time GPS tracking', 'Live map integration', 'Status timeline', 'Email notifications', 'SMS alerts', 'Estimated delivery date'],
    howTo: 'Go to Track Shipment page, enter your tracking ID, and click Track to view real-time status, location on map, and detailed timeline.',
  },
  stats: {
    statesCovered: '28+ states & 8 UTs',
    shipments: '10,000+',
    clients: '500+',
    onTimeRate: '99.2%',
  },
  industries: ['Manufacturing', 'Pharmaceuticals', 'FMCG', 'Automotive', 'Textiles', 'Electronics', 'Chemicals', 'Construction', 'Agriculture', 'E-Commerce', 'Retail', 'Technology'],
};

// Intent detection patterns
const INTENTS: { patterns: RegExp[]; intent: string }[] = [
  { patterns: [/hello|hi\b|hey|greetings|good\s*(morning|afternoon|evening)|namaste/i], intent: 'greeting' },
  { patterns: [/bye|goodbye|thank|thanks|ok\b|okay|got it|great|awesome|perfect/i], intent: 'farewell' },
  { patterns: [/cin|corporate\s*identification|company\s*number|registration\s*(number|no)/i], intent: 'cin' },
  { patterns: [/when.*incorporat|date.*incorporat|incorporat.*date|founded|started|established|how\s*old|company\s*age|since\s*when/i], intent: 'incorporation' },
  { patterns: [/director|founder|owner|ceo|management|leader|who\s*(runs?|owns?|manages?|leads?)|anupam|nitu/i], intent: 'directors' },
  { patterns: [/address|location|where|office|headquarters|hq|find\s*you|visit|situated|located|badlapur|thane|maharashtra|pincode|pin\s*code/i], intent: 'address' },
  { patterns: [/contact|phone|call|email|reach|get\s*in\s*touch|connect|talk/i], intent: 'contact' },
  { patterns: [/service|offer|provide|do\s*you\s*do|what.*do|help\s*with|solution|capability|facilities/i], intent: 'services' },
  { patterns: [/ocean|sea\s*freight|ship|shipping|fcl|lcl|container|maritime|vessel|port/i], intent: 'ocean_freight' },
  { patterns: [/air\s*freight|air\s*cargo|flight|plane|express\s*delivery|fast\s*shipping|urgent\s*cargo/i], intent: 'air_freight' },
  { patterns: [/road|truck|transport|inland|ground|surface|ftl|ptl|last\s*mile/i], intent: 'inland_transport' },
  { patterns: [/customs?|clearance|duty|import\s*duty|export\s*duty|documentation|brokerage|compliance/i], intent: 'customs' },
  { patterns: [/warehouse|storage|inventory|store|godown|distribution\s*center/i], intent: 'warehousing' },
  { patterns: [/supply\s*chain|scm|logistics\s*management|optimization|end.to.end/i], intent: 'supply_chain' },
  { patterns: [/track|trace|where\s*is\s*my|shipment\s*status|parcel|delivery\s*status|order\s*status|consignment/i], intent: 'tracking' },
  { patterns: [/price|cost|rate|charge|fee|quote|quotation|estimate|how\s*much|pricing|tariff|expensive|cheap|affordable/i], intent: 'pricing' },
  { patterns: [/import|export|international\s*trade|cross\s*border|foreign\s*trade|global\s*trade|exim/i], intent: 'import_export' },
  { patterns: [/capital|share|authorized|paid\s*up|investment|funding/i], intent: 'capital' },
  { patterns: [/agm|annual\s*general|meeting|financial|balance\s*sheet|accounts/i], intent: 'financial' },
  { patterns: [/roc|registrar|mca|ministry|government|legal|compliance|status/i], intent: 'legal' },
  { patterns: [/industry|sector|client|customer|who\s*do\s*you\s*serve|work\s*with/i], intent: 'industries' },
  { patterns: [/countries|international|global|worldwide|how\s*many\s*countries|coverage|network/i], intent: 'coverage' },
  { patterns: [/why\s*choose|why\s*you|advantage|benefit|different|special|unique|better/i], intent: 'why_us' },
  { patterns: [/time|hours|open|close|working|business\s*hours|available|timing/i], intent: 'hours' },
  { patterns: [/login|portal|account|sign\s*in|register|dashboard/i], intent: 'portal' },
];

function detectIntent(message: string): string[] {
  const msg = message.toLowerCase().trim();
  const matched: string[] = [];
  
  for (const { patterns, intent } of INTENTS) {
    for (const pattern of patterns) {
      if (pattern.test(msg)) {
        matched.push(intent);
        break;
      }
    }
  }
  
  return matched.length > 0 ? matched : ['unknown'];
}

function generateResponse(intents: string[], originalMessage: string): string {
  const responses: string[] = [];
  const handled = new Set<string>();

  for (const intent of intents) {
    if (handled.has(intent)) continue;
    handled.add(intent);

    switch (intent) {
      case 'greeting':
        responses.push(`Welcome to Whiteout Logistics Private Limited. I'm here to assist you with any questions about our company, services, shipment tracking, or other inquiries. How may I help you today?`);
        break;

      case 'farewell':
        responses.push(`Thank you for reaching out to Whiteout Logistics. We're committed to being your trusted logistics partner. If you have more questions in the future, don't hesitate to ask. Have a great day!`);
        break;

      case 'cin':
        responses.push(`Our Corporate Identification Number (CIN) is ${KNOWLEDGE.company.cin}. This is issued by the Ministry of Corporate Affairs, Government of India. Our company registration number is ${KNOWLEDGE.company.registrationNumber}.`);
        break;

      case 'incorporation':
        responses.push(`Whiteout Logistics Private Limited was incorporated on ${KNOWLEDGE.company.incorporationDate}. The company is approximately ${KNOWLEDGE.company.companyAge} old as of today. We are registered under ${KNOWLEDGE.company.roc}.`);
        break;

      case 'directors':
        const directorInfo = KNOWLEDGE.directors.map(d => 
          `• ${d.name} (${d.role}): ${d.description}`
        ).join('\n\n');
        responses.push(`Our company is led by ${KNOWLEDGE.directors.length} directors:\n\n${directorInfo}`);
        break;

      case 'address':
        responses.push(`Our registered office is located at:\n\n${KNOWLEDGE.address.full}\n\nDistrict: ${KNOWLEDGE.address.district}\nState: ${KNOWLEDGE.address.state}\nPIN Code: ${KNOWLEDGE.address.pincode}\n\nYou can find us on Google Maps through our Contact page.`);
        break;

      case 'contact':
        responses.push(`You can reach us through:\n\n• Email: ${KNOWLEDGE.contact.email}\n• Phone: ${KNOWLEDGE.contact.phone}\n• Business Hours: ${KNOWLEDGE.contact.businessHours}\n\nAlternatively, you can fill out the contact form on our website and our team will respond within 24 hours.`);
        break;

      case 'services':
        const serviceList = KNOWLEDGE.services.map(s => `• ${s.name}`).join('\n');
        responses.push(`We offer comprehensive logistics solutions:\n\n${serviceList}\n\nEach service is tailored to meet your specific business requirements. Would you like detailed information about any particular service?`);
        break;

      case 'ocean_freight':
        responses.push(`We are a domestic India-based logistics company. We specialize in road transport and truck freight within India. We do not provide ocean freight services. However, our truck transport covers all major ports in India for inland movement of goods.\n\nWould you like to know about our Full Truckload (FTL) or Part Truckload (PTL) services?`);
        break;

      case 'air_freight':
        responses.push(`We are a domestic road transport company and do not provide air freight services. Our specialty is truck-based goods transport across all Indian states.\n\nFor fast delivery within India, we offer express FTL (Full Truckload) services with dedicated vehicles for time-sensitive cargo.`);
        break;

      case 'inland_transport': {
        const ftl = KNOWLEDGE.services.find(s => s.name === 'Full Truckload (FTL)')!;
        const ptl = KNOWLEDGE.services.find(s => s.name === 'Part Truckload (PTL)')!;
        responses.push(`Our core truck transport services:\n\n${ftl.name}:\n${ftl.description}\nFeatures: ${ftl.features.join(', ')}\n\n${ptl.name}:\n${ptl.description}\nFeatures: ${ptl.features.join(', ')}\n\nWe cover all ${KNOWLEDGE.stats.statesCovered} of India.`);
        break;
      }

      case 'customs': {
        const docs = KNOWLEDGE.services.find(s => s.name === 'Documentation & Compliance')!;
        responses.push(`${docs.name}:\n\n${docs.description}\n\nKey features:\n${docs.features.map(f => `• ${f}`).join('\n')}\n\nWe handle all regulatory paperwork for smooth domestic goods transport.`);
        break;
      }

      case 'warehousing': {
        const wh = KNOWLEDGE.services.find(s => s.name === 'Warehousing & Storage')!;
        responses.push(`${wh.name}:\n\n${wh.description}\n\nKey features:\n${wh.features.map(f => `• ${f}`).join('\n')}`);
        break;
      }

      case 'supply_chain': {
        const sc = KNOWLEDGE.services.find(s => s.name === 'Supply Chain Solutions')!;
        responses.push(`${sc.name}:\n\n${sc.description}\n\nKey features:\n${sc.features.map(f => `• ${f}`).join('\n')}`);
        break;
      }

      case 'tracking':
        responses.push(`Shipment Tracking:\n\nTo track your shipment:\n1. Navigate to the "Track Shipment" page\n2. Enter your tracking ID (format: ${KNOWLEDGE.tracking.format})\n3. Click "Track" to view real-time status\n\nFeatures available:\n${KNOWLEDGE.tracking.features.map(f => `• ${f}`).join('\n')}\n\nIf you don't have a tracking ID, please contact us with your booking reference.`);
        break;

      case 'pricing':
        responses.push(`Pricing Information:\n\nOur rates are customized based on several factors:\n• Type and nature of cargo\n• Origin and destination within India\n• Shipment weight and dimensions\n• Service type (FTL, PTL, last-mile)\n• Volume and frequency of shipments\n• Special handling requirements\n\nFor an accurate quotation, please call us at ${KNOWLEDGE.contact.phone} or email ${KNOWLEDGE.contact.email}. Our team typically responds within 24 hours.`);
        break;

      case 'import_export':
        responses.push(`We are a domestic India-based logistics company. Our focus is on inland truck transport and road freight within India.\n\nOur domestic services include:\n• Full Truckload (FTL) across all states\n• Part Truckload (PTL) for smaller shipments\n• Last-mile delivery to any location in India\n• Warehousing and storage\n• Documentation and compliance (e-way bills, GST)\n\nWe cover all ${KNOWLEDGE.stats.statesCovered} of India.`);
        break;

      case 'capital':
        responses.push(`Company Financial Structure:\n\n• Authorized Share Capital: ${KNOWLEDGE.company.authorizedCapital}\n• Paid-up Capital: ${KNOWLEDGE.company.paidUpCapital}\n• Company Type: ${KNOWLEDGE.company.type}\n• Category: ${KNOWLEDGE.company.category}\n\nWe are a fully compliant private limited company registered with MCA.`);
        break;

      case 'financial':
        responses.push(`Financial & AGM Information:\n\n• Last Annual General Meeting: ${KNOWLEDGE.company.lastAgm}\n• Last Financial Update Filed: ${KNOWLEDGE.company.lastFinancialUpdate}\n• Authorized Capital: ${KNOWLEDGE.company.authorizedCapital}\n• Paid-up Capital: ${KNOWLEDGE.company.paidUpCapital}\n• Company Status: ${KNOWLEDGE.company.status}\n\nAll statutory filings are up to date with the Registrar of Companies.`);
        break;

      case 'legal':
        responses.push(`Legal & Compliance Information:\n\n• Company Name: ${KNOWLEDGE.company.name}\n• CIN: ${KNOWLEDGE.company.cin}\n• Registration Number: ${KNOWLEDGE.company.registrationNumber}\n• Registrar: ${KNOWLEDGE.company.roc}\n• Company Type: ${KNOWLEDGE.company.type}\n• Status: ${KNOWLEDGE.company.status}\n• State: ${KNOWLEDGE.company.state}\n\nWe maintain full compliance with all MCA regulations and requirements.`);
        break;

      case 'industries':
        responses.push(`We serve clients across diverse industries:\n\n${KNOWLEDGE.industries.map(i => `• ${i}`).join('\n')}\n\nWith ${KNOWLEDGE.stats.clients} satisfied clients, we understand the unique logistics requirements of each sector.`);
        break;

      case 'coverage':
        responses.push(`Pan-India Coverage:\n\n• States & UTs Covered: ${KNOWLEDGE.stats.statesCovered}\n• Deliveries Completed: ${KNOWLEDGE.stats.shipments}\n• Active Clients: ${KNOWLEDGE.stats.clients}\n• On-Time Delivery Rate: ${KNOWLEDGE.stats.onTimeRate}\n\nWe operate across all major national highways and state roads, covering every industrial corridor, metro city, and tier-2/tier-3 town in India.`);
        break;

      case 'why_us':
        responses.push(`Why Choose Whiteout Logistics:\n\n• MCA Registered: Fully compliant company (CIN: ${KNOWLEDGE.company.cin})\n• Pan-India Network: Coverage across ${KNOWLEDGE.stats.statesCovered}\n• Reliability: ${KNOWLEDGE.stats.onTimeRate} on-time delivery rate\n• Experience: ${KNOWLEDGE.stats.shipments} deliveries completed\n• Technology: Real-time GPS tracking with live Google Maps\n• Expert Team: Led by experienced directors with deep industry knowledge\n• Complete Services: FTL, PTL, last-mile, warehousing, and supply chain\n• Customer Focus: Dedicated support, call us at ${KNOWLEDGE.contact.phone}`);
        break;

      case 'hours':
        responses.push(`Business Hours:\n\n${KNOWLEDGE.contact.businessHours}\n\nOur team is available during these hours for inquiries, support, and operations. For urgent matters outside business hours, please email us and we'll respond as soon as possible.`);
        break;

      case 'portal':
        responses.push(`Client Portal:\n\nOur online portal allows you to:\n• Track shipments in real-time\n• View shipment history\n• Download documentation\n• Request quotes\n• Manage bookings\n\nYou can access the portal by clicking "Client Portal" in the navigation menu. New users can register for an account, and existing clients can sign in with their credentials.`);
        break;

      case 'unknown':
      default:
        // Analyze the message for any partial matches or keywords
        const msg = originalMessage.toLowerCase();
        
        if (msg.length < 3) {
          responses.push(`I'd be happy to help. Could you please provide more details about what you'd like to know?`);
        } else if (msg.includes('?')) {
          responses.push(`Thank you for your question. While I may not have the specific answer you're looking for, I can help you with:\n\n• Company information (CIN, registration, directors)\n• Services (ocean freight, air freight, customs, warehousing)\n• Shipment tracking\n• Contact details and office location\n• Pricing and quotations\n\nCould you please rephrase your question, or would you like information on any of these topics?\n\nFor specific inquiries not covered here, please contact us at ${KNOWLEDGE.contact.email}.`);
        } else {
          responses.push(`I understand you're looking for information. Here's what I can assist you with:\n\n• Company Details: Registration, CIN, directors, legal status\n• Services: Ocean freight, air freight, road transport, customs, warehousing\n• Tracking: How to track your shipments\n• Contact: Phone, email, office address\n• Pricing: How to get a quotation\n\nPlease ask about any specific topic, or contact us at ${KNOWLEDGE.contact.email} for personalized assistance.`);
        }
        break;
    }
  }

  // Combine responses if multiple intents detected
  if (responses.length > 1) {
    return responses.join('\n\n---\n\n');
  }
  
  return responses[0] || `I'm here to help with information about Whiteout Logistics. Please feel free to ask about our services, company details, tracking, or contact information.`;
}

export default function Chatbot() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [msgs, setMsgs] = useState<Msg[]>([
    { from: 'bot', text: `Welcome to Whiteout Logistics Private Limited.\n\nI'm your AI assistant, equipped with comprehensive knowledge about our company, services, and operations. I can help you with:\n\n• Company information & registration details\n• Our logistics services\n• Shipment tracking guidance\n• Contact information\n• Pricing inquiries\n• And much more\n\nHow may I assist you today?` },
  ]);
  const [typing, setTyping] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => { 
    endRef.current?.scrollIntoView({ behavior: 'smooth' }); 
  }, [msgs]);

  const send = (text?: string) => {
    const msg = (text || input).trim();
    if (!msg) return;
    setInput('');
    setMsgs((p) => [...p, { from: 'user', text: msg }]);
    setTyping(true);
    
    // Simulate thinking time based on message complexity
    const thinkTime = Math.min(400 + msg.length * 10, 1200);
    
    setTimeout(() => {
      const intents = detectIntent(msg);
      const response = generateResponse(intents, msg);
      setMsgs((p) => [...p, { from: 'bot', text: response }]);
      setTyping(false);
    }, thinkTime);
  };

  const suggestions = ['What services do you offer?', 'Company registration details', 'How to track shipment?', 'Contact information', 'Who are the directors?'];

  return (
    <>
      {/* Toggle button */}
      <button
        onClick={() => setOpen(!open)}
        className={`fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full shadow-lg flex items-center justify-center transition-all duration-300 ${
          open ? 'bg-navy hover:bg-navy-light' : 'bg-blue hover:bg-blue-dark'
        }`}
      >
        {open ? <X size={20} className="text-white" /> : <MessageSquare size={20} className="text-white" />}
      </button>

      {/* Chat window */}
      <div className={`fixed bottom-24 right-6 z-50 w-[400px] max-w-[calc(100vw-2rem)] transition-all duration-400 ${
        open ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 translate-y-4 pointer-events-none'
      }`}>
        <div className="bg-white rounded-2xl shadow-2xl border border-border overflow-hidden flex flex-col" style={{ height: 540 }}>
          {/* Header */}
          <div className="bg-navy px-5 py-4 flex-shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue/20 rounded-xl flex items-center justify-center">
                <Sparkles size={18} className="text-blue-light" />
              </div>
              <div>
                <div className="text-white text-[14px] font-semibold">Whiteout AI Assistant</div>
                <div className="flex items-center gap-1.5 text-[11px] text-white/40">
                  <span className="w-1.5 h-1.5 bg-green-400 rounded-full" />
                  Intelligent Assistant • Online
                </div>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-off-white">
            {msgs.map((msg, i) => (
              <div key={i} className={`flex ${msg.from === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[88%] rounded-xl px-4 py-3 text-[13px] leading-[1.7] ${
                  msg.from === 'user'
                    ? 'bg-navy text-white rounded-br-sm'
                    : 'bg-white text-text border border-border rounded-bl-sm shadow-sm'
                }`}>
                  {msg.text.split('\n').map((line, j) => (
                    <span key={j}>
                      {line}
                      {j < msg.text.split('\n').length - 1 && <br />}
                    </span>
                  ))}
                </div>
              </div>
            ))}
            
            {typing && (
              <div className="flex justify-start">
                <div className="bg-white text-text border border-border rounded-xl rounded-bl-sm px-4 py-3 shadow-sm">
                  <div className="flex items-center gap-2">
                    <div className="flex gap-1">
                      {[0, 1, 2].map((i) => (
                        <span 
                          key={i} 
                          className="w-1.5 h-1.5 bg-blue rounded-full animate-bounce" 
                          style={{ animationDelay: `${i * 0.15}s` }} 
                        />
                      ))}
                    </div>
                    <span className="text-[11px] text-slate">Thinking...</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={endRef} />
          </div>

          {/* Quick suggestions */}
          {msgs.length <= 2 && (
            <div className="px-4 py-3 border-t border-border bg-white flex-shrink-0">
              <p className="text-[10px] text-text-light font-medium uppercase tracking-wider mb-2">Quick Questions</p>
              <div className="flex flex-wrap gap-1.5">
                {suggestions.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => send(s)}
                    className="text-[11px] bg-off-white text-text-light px-3 py-1.5 rounded-lg hover:bg-blue/[0.08] hover:text-blue transition-colors font-medium border border-border"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Input */}
          <div className="p-3 bg-white border-t border-border flex-shrink-0">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && send()}
                placeholder="Ask me anything about Whiteout Logistics..."
                className="flex-1 px-4 py-2.5 bg-off-white rounded-lg outline-none text-[13px] text-navy placeholder:text-slate/50 focus:ring-2 focus:ring-blue/10 transition-all border border-transparent focus:border-blue/20"
              />
              <button
                onClick={() => send()}
                disabled={!input.trim()}
                className="bg-navy hover:bg-navy-light text-white px-4 py-2.5 rounded-lg transition-all disabled:opacity-30"
              >
                <Send size={16} />
              </button>
            </div>
            <p className="text-[10px] text-text-light/50 text-center mt-2">
              AI-powered • Trained on Whiteout Logistics knowledge base
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
