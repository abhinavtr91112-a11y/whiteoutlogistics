import { useState } from 'react';
import { Send, MapPin, Phone, Mail, Clock, Building2 } from 'lucide-react';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => setSent(false), 4000);
  };

  const info = [
    {
      icon: <MapPin size={20} />,
      title: 'Registered Office',
      lines: ['Flat No. 204/b, Sangam Ap,', 'Barrage Road, Badlapur We,', 'Thane, Maharashtra — 421503'],
    },
    {
      icon: <Phone size={20} />,
      title: 'Phone',
      lines: ['+91 9767247858'],
    },
    {
      icon: <Mail size={20} />,
      title: 'Email',
      lines: ['info@whiteoutlogistics.com'],
    },
    {
      icon: <Clock size={20} />,
      title: 'Business Hours',
      lines: ['Monday – Saturday', '9:00 AM — 6:00 PM IST'],
    },
    {
      icon: <Building2 size={20} />,
      title: 'Registration',
      lines: ['ROC: RoC-Mumbai II', 'Reg. No: 423370'],
    },
  ];

  return (
    <section className="pt-28 pb-20 bg-white min-h-screen">
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        {/* Header */}
        <div className="max-w-2xl mb-16">
          <div className="flex items-center gap-3 mb-4">
            <span className="w-10 h-[1px] bg-blue" />
            <span className="text-blue text-[13px] font-semibold tracking-widest uppercase">Get in Touch</span>
          </div>
          <h2 className="text-3xl lg:text-[2.8rem] font-extrabold text-navy leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
            Contact Us
          </h2>
          <p className="text-text-light text-base mt-3">
            Have questions about our transport services? Our team is ready to assist you.
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-12">
          {/* Info */}
          <div className="lg:col-span-2 space-y-1">
            {info.map((item, i) => (
              <div key={i} className="flex items-start gap-4 p-4 rounded-xl hover:bg-off-white transition-colors group">
                <div className="w-10 h-10 rounded-xl bg-blue/[0.07] text-blue flex items-center justify-center flex-shrink-0 group-hover:bg-blue group-hover:text-white transition-all">
                  {item.icon}
                </div>
                <div>
                  <h4 className="text-navy text-[14px] font-semibold">{item.title}</h4>
                  {item.lines.map((line, j) => (
                    <p key={j} className="text-text-light text-[13px] leading-relaxed">{line}</p>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Form */}
          <div className="lg:col-span-3">
            <div className="bg-white border border-border rounded-2xl p-7 lg:p-9 shadow-sm">
              {sent ? (
                <div className="text-center py-16 anim-scale-in">
                  <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold text-navy mb-1">Message Sent</h3>
                  <p className="text-text-light text-[14px]">We'll respond within 24 business hours.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid md:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-[13px] font-semibold text-navy mb-2">Full Name *</label>
                      <input
                        type="text"
                        required
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        className="w-full px-4 py-3 rounded-lg border border-border text-[14px] text-navy outline-none focus:border-blue focus:ring-[3px] focus:ring-blue/[0.08] transition-all placeholder:text-slate/50"
                        placeholder="Your full name"
                      />
                    </div>
                    <div>
                      <label className="block text-[13px] font-semibold text-navy mb-2">Email *</label>
                      <input
                        type="email"
                        required
                        value={form.email}
                        onChange={(e) => setForm({ ...form, email: e.target.value })}
                        className="w-full px-4 py-3 rounded-lg border border-border text-[14px] text-navy outline-none focus:border-blue focus:ring-[3px] focus:ring-blue/[0.08] transition-all placeholder:text-slate/50"
                        placeholder="your@email.com"
                      />
                    </div>
                  </div>
                  <div className="grid md:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-[13px] font-semibold text-navy mb-2">Phone</label>
                      <input
                        type="tel"
                        value={form.phone}
                        onChange={(e) => setForm({ ...form, phone: e.target.value })}
                        className="w-full px-4 py-3 rounded-lg border border-border text-[14px] text-navy outline-none focus:border-blue focus:ring-[3px] focus:ring-blue/[0.08] transition-all placeholder:text-slate/50"
                        placeholder="+91 XXXXXXXXXX"
                      />
                    </div>
                    <div>
                      <label className="block text-[13px] font-semibold text-navy mb-2">Subject *</label>
                      <select
                        required
                        value={form.subject}
                        onChange={(e) => setForm({ ...form, subject: e.target.value })}
                        className="w-full px-4 py-3 rounded-lg border border-border text-[14px] text-navy outline-none focus:border-blue focus:ring-[3px] focus:ring-blue/[0.08] transition-all bg-white"
                      >
                        <option value="">Select a subject</option>
                        <option>Full Truckload (FTL)</option>
                        <option>Part Truckload (PTL)</option>
                        <option>Warehousing</option>
                        <option>Request a Quote</option>
                        <option>Tracking Inquiry</option>
                        <option>Partnership</option>
                        <option>Other</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-[13px] font-semibold text-navy mb-2">Message *</label>
                    <textarea
                      rows={5}
                      required
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      className="w-full px-4 py-3 rounded-lg border border-border text-[14px] text-navy outline-none focus:border-blue focus:ring-[3px] focus:ring-blue/[0.08] transition-all resize-none placeholder:text-slate/50"
                      placeholder="Describe your transport requirements..."
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-navy hover:bg-navy-light text-white py-3.5 rounded-lg text-[14px] font-semibold tracking-wide transition-all flex items-center justify-center gap-2"
                  >
                    <Send size={16} /> Send Message
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>

        {/* Map */}
        <div className="mt-16 bg-white border border-border rounded-2xl overflow-hidden shadow-sm">
          <div className="px-6 lg:px-8 py-5 border-b border-border">
            <h3 className="text-navy text-[16px] font-bold">Our Location</h3>
            <p className="text-text-light text-[13px] mt-0.5">Badlapur, Thane, Maharashtra — 421503</p>
          </div>
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60340.27596185498!2d73.20582455!3d19.1717741!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7959fd4e6a8e3%3A0x51f7fdc7c7c2b385!2sBadlapur%2C%20Maharashtra%20421503!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
            width="100%"
            height="320"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="Office Location"
            className="block"
          />
        </div>
      </div>
    </section>
  );
}
