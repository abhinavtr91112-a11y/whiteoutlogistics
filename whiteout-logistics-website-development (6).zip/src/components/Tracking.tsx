import { useState } from 'react';
import { Search, Package, CheckCircle2, Truck, MapPin, Clock, ArrowRight, Loader2 } from 'lucide-react';

export default function Tracking() {
  const [trackingId, setTrackingId] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(false);

  const handleTrack = () => {
    if (!trackingId.trim()) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setResult(true);
    }, 1800);
  };

  const steps = [
    { icon: <Package size={18} />, title: 'Order Confirmed', loc: 'Mumbai, Maharashtra', date: '15 Jan 2025, 10:30 AM', done: true },
    { icon: <CheckCircle2 size={18} />, title: 'Picked Up', loc: 'Bhiwandi Warehouse, Maharashtra', date: '16 Jan 2025, 02:15 PM', done: true },
    { icon: <Truck size={18} />, title: 'In Transit', loc: 'NH-48, Rajasthan', date: '18 Jan 2025, 08:00 AM', current: true },
    { icon: <MapPin size={18} />, title: 'Arrived at Hub', loc: 'Delhi NCR Distribution Centre', date: 'Expected 19 Jan 2025', done: false },
    { icon: <CheckCircle2 size={18} />, title: 'Delivered', loc: 'New Delhi, Delhi', date: 'Expected 20 Jan 2025', done: false },
  ];

  return (
    <section className="pt-28 pb-20 bg-off-white min-h-screen">
      <div className="max-w-6xl mx-auto px-5 lg:px-8">
        {/* Header */}
        <div className="max-w-2xl mb-12">
          <div className="flex items-center gap-3 mb-4">
            <span className="w-10 h-[1px] bg-blue" />
            <span className="text-blue text-[13px] font-semibold tracking-widest uppercase">Track & Trace</span>
          </div>
          <h2 className="text-3xl lg:text-[2.8rem] font-extrabold text-navy leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
            Track Your Shipment
          </h2>
          <p className="text-text-light text-base mt-3">
            Enter your tracking number to view real-time status and location of your goods on Indian roads.
          </p>
        </div>

        {/* Search */}
        <div className="max-w-2xl mb-12">
          <div className="flex bg-white border border-border rounded-xl overflow-hidden shadow-sm focus-within:border-blue focus-within:shadow-[0_0_0_3px_rgba(29,114,184,0.08)] transition-all">
            <div className="flex items-center pl-5 text-text-light">
              <Search size={20} />
            </div>
            <input
              type="text"
              value={trackingId}
              onChange={(e) => setTrackingId(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleTrack()}
              placeholder="Enter tracking ID — e.g. WL-2025-001234"
              className="flex-1 py-4 px-4 text-[15px] outline-none text-navy placeholder:text-slate/60"
            />
            <button
              onClick={handleTrack}
              disabled={loading || !trackingId.trim()}
              className="bg-navy hover:bg-navy-light text-white px-6 lg:px-8 text-[14px] font-semibold tracking-wide transition-all disabled:opacity-40 flex items-center gap-2"
            >
              {loading ? <Loader2 size={18} className="animate-spin" /> : <>Track <ArrowRight size={15} /></>}
            </button>
          </div>
          <p className="text-text-light/60 text-[12px] mt-2 pl-1">
            Enter any tracking ID and click Track to view a demo result.
          </p>
        </div>

        {/* Result */}
        {result && (
          <div className="anim-fade-up space-y-6">
            {/* Status card */}
            <div className="bg-white border border-border rounded-2xl overflow-hidden shadow-sm">
              <div className="bg-navy px-6 lg:px-8 py-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="text-white/40 text-[12px] font-medium tracking-wider uppercase">Tracking ID</div>
                  <div className="text-white text-xl font-bold mt-0.5">{trackingId || 'WL-2025-001234'}</div>
                </div>
                <div className="flex items-center gap-2 bg-blue/20 text-blue-light px-4 py-2 rounded-lg text-[13px] font-semibold tracking-wide">
                  <Truck size={16} />
                  In Transit
                </div>
              </div>

              <div className="p-6 lg:p-8">
                {/* Info grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
                  {[
                    { label: 'Origin', value: 'Mumbai, MH' },
                    { label: 'Destination', value: 'New Delhi' },
                    { label: 'Weight', value: '1,200 Kg' },
                    { label: 'ETA', value: '20 Jan 2025' },
                  ].map((info, i) => (
                    <div key={i} className="bg-off-white rounded-xl p-4">
                      <div className="text-[11px] text-text-light font-medium tracking-wider uppercase">{info.label}</div>
                      <div className="text-navy text-[14px] font-semibold mt-1">{info.value}</div>
                    </div>
                  ))}
                </div>

                {/* Timeline */}
                <div className="space-y-0">
                  {steps.map((step, i) => (
                    <div key={i} className="flex gap-5">
                      <div className="flex flex-col items-center">
                        <div className={`w-9 h-9 rounded-full flex items-center justify-center border-2 ${
                          step.done
                            ? 'bg-green-50 border-green-500 text-green-600'
                            : step.current
                            ? 'bg-blue/10 border-blue text-blue shadow-[0_0_0_4px_rgba(29,114,184,0.1)]'
                            : 'bg-gray-50 border-gray-200 text-gray-300'
                        }`}>
                          {step.icon}
                        </div>
                        {i < steps.length - 1 && (
                          <div className={`w-[2px] h-14 ${step.done || step.current ? 'bg-green-200' : 'bg-gray-100'}`} />
                        )}
                      </div>
                      <div className="pb-6">
                        <h4 className={`text-[15px] font-semibold ${
                          step.done || step.current ? 'text-navy' : 'text-gray-300'
                        }`}>
                          {step.title}
                        </h4>
                        <p className="text-text-light text-[13px] mt-0.5">{step.loc}</p>
                        <div className="flex items-center gap-1.5 mt-1 text-[12px] text-text-light/60">
                          <Clock size={11} /> {step.date}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Map */}
            <div className="bg-white border border-border rounded-2xl overflow-hidden shadow-sm">
              <div className="px-6 lg:px-8 py-5 border-b border-border">
                <h3 className="text-navy text-[16px] font-bold">Live Shipment Route</h3>
                <p className="text-text-light text-[13px] mt-0.5">Mumbai, Maharashtra → New Delhi</p>
              </div>
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d7483980.906533889!2d73.71849285!3d23.40476255!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e0!4m5!1s0x3be7c6306644edc1%3A0x5da4ed8f8d648c69!2sMumbai%2C%20Maharashtra!3m2!1d19.0759837!2d72.8776559!4m5!1s0x390cfd5b347eb62d%3A0x52c2b7494e204dce!2sNew%20Delhi%2C%20Delhi!3m2!1d28.6139391!2d77.2090212!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
                width="100%"
                height="380"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Shipment Route"
                className="block"
              />
            </div>
          </div>
        )}

        {/* Default map */}
        {!result && (
          <div className="bg-white border border-border rounded-2xl overflow-hidden shadow-sm">
            <div className="px-6 lg:px-8 py-5 border-b border-border">
              <h3 className="text-navy text-[16px] font-bold">Our Location</h3>
              <p className="text-text-light text-[13px] mt-0.5">Badlapur, Thane, Maharashtra — 421503</p>
            </div>
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60340.27596185498!2d73.20582455!3d19.1717741!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7959fd4e6a8e3%3A0x51f7fdc7c7c2b385!2sBadlapur%2C%20Maharashtra%20421503!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
              width="100%"
              height="400"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Office Location"
              className="block"
            />
          </div>
        )}
      </div>
    </section>
  );
}
