import { useState, useEffect, type ReactNode } from 'react';
import { Menu, X, Home, Building2, Truck, MapPin, Phone, LogIn } from 'lucide-react';

interface Props {
  current: string;
  navigate: (p: string) => void;
}

const links: { id: string; label: string; icon: ReactNode }[] = [
  { id: 'home', label: 'Home', icon: <Home size={20} /> },
  { id: 'about', label: 'About', icon: <Building2 size={20} /> },
  { id: 'services', label: 'Services', icon: <Truck size={20} /> },
  { id: 'tracking', label: 'Track', icon: <MapPin size={20} /> },
  { id: 'contact', label: 'Contact', icon: <Phone size={20} /> },
];

export default function Navbar({ current, navigate }: Props) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', fn, { passive: true });
    return () => window.removeEventListener('scroll', fn);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-white shadow-[0_2px_12px_rgba(0,0,0,0.1)] border-b border-border'
          : 'bg-navy/90 backdrop-blur-md'
      }`}
    >
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        <div className="flex items-center justify-between h-[68px]">
          {/* Logo */}
          <button
            onClick={() => navigate('home')}
            className="flex items-center gap-3 group"
          >
            <img
              src="/images/logo.png"
              alt="Whiteout Logistics"
              className="h-10 w-auto rounded-lg"
            />
            <div className="hidden sm:flex flex-col">
              <span className={`text-[15px] font-bold tracking-wide leading-none transition-colors ${
                scrolled ? 'text-navy' : 'text-white'
              }`}>
                WHITEOUT
              </span>
              <span className={`text-[9px] font-medium tracking-[0.1em] leading-none mt-1 transition-colors ${
                scrolled ? 'text-blue' : 'text-blue-light'
              }`}>
                LOGISTICS PRIVATE LIMITED
              </span>
            </div>
          </button>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {links.map((l) => (
              <button
                key={l.id}
                onClick={() => navigate(l.id)}
                title={l.label}
                className={`relative flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                  current === l.id
                    ? scrolled
                      ? 'bg-blue text-white'
                      : 'bg-white/20 text-white'
                    : scrolled
                      ? 'text-navy/60 hover:text-navy hover:bg-gray-100'
                      : 'text-white/60 hover:text-white hover:bg-white/10'
                }`}
              >
                {l.icon}
                <span className="text-[12px] font-semibold tracking-wide hidden lg:inline">{l.label}</span>
              </button>
            ))}
            <button
              onClick={() => navigate('login')}
              title="Client Portal"
              className={`ml-2 flex items-center gap-2 px-5 py-2.5 rounded-lg text-[12px] font-semibold tracking-wide transition-all ${
                scrolled
                  ? 'bg-navy text-white hover:bg-navy-light'
                  : 'bg-white text-navy hover:bg-white/90'
              }`}
            >
              <LogIn size={18} />
              <span className="hidden lg:inline">Portal</span>
            </button>
          </nav>

          {/* Mobile toggle */}
          <button
            onClick={() => setOpen(!open)}
            className={`md:hidden p-2 rounded-lg transition-colors ${
              scrolled ? 'text-navy hover:bg-gray-100' : 'text-white hover:bg-white/10'
            }`}
          >
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`md:hidden fixed inset-0 top-[68px] bg-white z-40 transition-all duration-400 ${
          open ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <nav className="flex flex-col p-6 gap-1">
          {links.map((l) => (
            <button
              key={l.id}
              onClick={() => { navigate(l.id); setOpen(false); }}
              className={`flex items-center gap-4 px-4 py-3.5 rounded-xl text-[15px] font-medium transition-all ${
                current === l.id
                  ? 'bg-navy text-white'
                  : 'text-text hover:bg-off-white'
              }`}
            >
              <span className={current === l.id ? 'text-blue-light' : 'text-text-light'}>{l.icon}</span>
              {l.label}
            </button>
          ))}
          <div className="mt-4 pt-4 border-t border-border">
            <button
              onClick={() => { navigate('login'); setOpen(false); }}
              className="w-full flex items-center justify-center gap-2 py-3.5 bg-blue text-white rounded-xl text-[15px] font-semibold hover:bg-blue-dark transition-colors"
            >
              <LogIn size={18} />
              Client Portal
            </button>
          </div>
        </nav>
      </div>
    </header>
  );
}
