import { ArrowUp } from 'lucide-react';

interface Props {
  navigate: (p: string) => void;
}

export default function Footer({ navigate }: Props) {
  const go = (page: string) => {
    navigate(page);
    window.scrollTo({ top: 0 });
  };

  return (
    <footer className="bg-navy text-white">
      <div className="max-w-7xl mx-auto px-5 lg:px-8 pt-16 pb-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10 mb-14">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-5">
              <img src="/images/logo.png" alt="Whiteout Logistics" className="h-10 rounded-lg" />
              <div>
                <div className="text-[15px] font-bold tracking-wide">WHITEOUT</div>
                <div className="text-blue-light text-[9px] tracking-[0.12em] font-medium">LOGISTICS PRIVATE LIMITED</div>
              </div>
            </div>
            <p className="text-white/30 text-[13px] leading-relaxed mb-5">
              MCA-registered private company providing domestic truck transport and logistics services across India since 2024.
            </p>
            <p className="text-white/20 text-[11px]">
              CIN: U52290MH2024PTC423370
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="text-[13px] font-semibold tracking-wider uppercase text-white/50 mb-5">Navigation</h4>
            <ul className="space-y-2.5">
              {[
                { label: 'Home', page: 'home' },
                { label: 'About', page: 'about' },
                { label: 'Services', page: 'services' },
                { label: 'Track Shipment', page: 'tracking' },
                { label: 'Contact', page: 'contact' },
                { label: 'Client Portal', page: 'login' },
              ].map((l, i) => (
                <li key={i}>
                  <button
                    onClick={() => go(l.page)}
                    className="text-white/30 hover:text-blue-light text-[13px] transition-colors"
                  >
                    {l.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-[13px] font-semibold tracking-wider uppercase text-white/50 mb-5">Services</h4>
            <ul className="space-y-2.5">
              {['Full Truckload (FTL)', 'Part Truckload (PTL)', 'Last-Mile Delivery', 'Documentation & Compliance', 'Warehousing & Storage', 'Supply Chain Solutions'].map((s, i) => (
                <li key={i} className="text-white/30 text-[13px]">{s}</li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-[13px] font-semibold tracking-wider uppercase text-white/50 mb-5">Contact</h4>
            <div className="space-y-3 text-[13px]">
              <p className="text-white/30 leading-relaxed">
                Flat No. 204/b, Sangam Ap, Barrage Road, Badlapur, Thane, Maharashtra — 421503
              </p>
              <p className="text-white/30">info@whiteoutlogistics.com</p>
              <p className="text-white/50 font-medium">+91 9767247858</p>
              <p className="text-white/30">Mon – Sat, 9 AM – 6 PM IST</p>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-white/[0.06] pt-7 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-white/20 text-[12px]">
            © {new Date().getFullYear()} Whiteout Logistics Private Limited. All rights reserved.
          </p>
          <div className="flex gap-5 text-white/20 text-[12px]">
            <span className="hover:text-white/50 cursor-pointer transition-colors">Privacy Policy</span>
            <span className="hover:text-white/50 cursor-pointer transition-colors">Terms of Service</span>
          </div>
        </div>
      </div>

      {/* Scroll top */}
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        className="fixed bottom-6 left-6 z-40 w-10 h-10 bg-white/[0.06] hover:bg-white/[0.12] border border-white/[0.08] rounded-lg flex items-center justify-center text-white/40 hover:text-white transition-all"
      >
        <ArrowUp size={16} />
      </button>
    </footer>
  );
}
