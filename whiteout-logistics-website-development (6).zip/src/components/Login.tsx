import { useState } from 'react';
import { Eye, EyeOff, Lock, Mail, User, ArrowRight, Loader2, ShieldCheck } from 'lucide-react';

interface Props {
  navigate: (p: string) => void;
}

export default function Login({ navigate }: Props) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [showPw, setShowPw] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSuccess(true);
      setTimeout(() => { setSuccess(false); navigate('home'); }, 2000);
    }, 1500);
  };

  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-navy" />
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)',
        backgroundSize: '40px 40px',
      }} />
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue/[0.04] rounded-full -translate-y-1/2 translate-x-1/4" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-blue/[0.03] rounded-full translate-y-1/2 -translate-x-1/4" />

      <div className="relative z-10 w-full max-w-[420px] mx-4 py-12">
        {/* Logo */}
        <div className="text-center mb-10">
          <button onClick={() => navigate('home')} className="inline-block mb-5">
            <img src="/images/logo.png" alt="Whiteout Logistics" className="h-14 mx-auto rounded-xl" />
          </button>
          <h1 className="text-white text-xl font-bold">
            {mode === 'login' ? 'Client Portal' : 'Create Account'}
          </h1>
          <p className="text-white/30 text-[13px] mt-1">
            {mode === 'login' ? 'Sign in to manage your shipments' : 'Register for shipment management access'}
          </p>
        </div>

        {/* Success overlay */}
        {success && (
          <div className="absolute inset-0 flex items-center justify-center z-50 anim-scale-in">
            <div className="bg-white rounded-2xl p-12 text-center shadow-2xl">
              <div className="w-14 h-14 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-7 h-7 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-lg font-bold text-navy mb-1">
                {mode === 'login' ? 'Welcome Back' : 'Account Created'}
              </h3>
              <p className="text-text-light text-[13px]">Redirecting...</p>
            </div>
          </div>
        )}

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-2xl p-7 lg:p-8">
          {/* Toggle */}
          <div className="flex bg-off-white rounded-lg p-1 mb-7">
            <button
              onClick={() => setMode('login')}
              className={`flex-1 py-2.5 rounded-md text-[13px] font-semibold transition-all ${
                mode === 'login' ? 'bg-navy text-white shadow-sm' : 'text-text-light hover:text-navy'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => setMode('register')}
              className={`flex-1 py-2.5 rounded-md text-[13px] font-semibold transition-all ${
                mode === 'register' ? 'bg-navy text-white shadow-sm' : 'text-text-light hover:text-navy'
              }`}
            >
              Register
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <div>
                <label className="block text-[13px] font-semibold text-navy mb-2">Full Name</label>
                <div className="relative">
                  <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 rounded-lg border border-border text-[14px] text-navy outline-none focus:border-blue focus:ring-[3px] focus:ring-blue/[0.08] transition-all placeholder:text-slate/50"
                    placeholder="Enter your full name"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-[13px] font-semibold text-navy mb-2">Email Address</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-lg border border-border text-[14px] text-navy outline-none focus:border-blue focus:ring-[3px] focus:ring-blue/[0.08] transition-all placeholder:text-slate/50"
                  placeholder="your@email.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-[13px] font-semibold text-navy mb-2">Password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate" />
                <input
                  type={showPw ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-11 py-3 rounded-lg border border-border text-[14px] text-navy outline-none focus:border-blue focus:ring-[3px] focus:ring-blue/[0.08] transition-all placeholder:text-slate/50"
                  placeholder="••••••••"
                />
                <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate hover:text-navy transition-colors">
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {mode === 'login' && (
              <div className="flex justify-between items-center text-[13px]">
                <label className="flex items-center gap-2 text-text-light cursor-pointer">
                  <input type="checkbox" className="w-3.5 h-3.5 rounded border-border text-blue focus:ring-blue/30" />
                  Remember me
                </label>
                <button type="button" className="text-blue hover:text-blue-dark font-medium transition-colors">
                  Forgot password?
                </button>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-navy hover:bg-navy-light text-white py-3.5 rounded-lg text-[14px] font-semibold tracking-wide transition-all flex items-center justify-center gap-2 disabled:opacity-60 mt-2"
            >
              {loading ? (
                <Loader2 size={18} className="animate-spin" />
              ) : (
                <>
                  {mode === 'login' ? 'Sign In' : 'Create Account'}
                  <ArrowRight size={16} />
                </>
              )}
            </button>
          </form>

          <div className="flex items-center justify-center gap-2 mt-6 text-[12px] text-text-light/60">
            <ShieldCheck size={13} />
            256-bit SSL Encrypted
          </div>
        </div>

        <div className="text-center mt-6">
          <button onClick={() => navigate('home')} className="text-white/30 hover:text-white/60 text-[13px] transition-colors">
            ← Return to website
          </button>
        </div>
      </div>
    </section>
  );
}
